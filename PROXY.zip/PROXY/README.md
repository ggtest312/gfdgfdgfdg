## UrgStresser.com TLS Methods

### Installation:

```shell
sh install.sh
npm i randomstring
```

### Usage:

```shell
node http1.js GET "https://website.com" http.txt 120 64 1
node http2.js GET "https://website.com" http.txt 120 64 1
```

Use new proxies from this url https://proxyscrape.com/free-proxy-list

Enjoy using methods, if you want to use our real power, FREE stress test at https://urgstresser.com

![showcase](https://i.imgur.com/54NyCVS.gif)
