# chmod 0777 * -R 
# ./install.sh
red=$(tput setaf 1);
white=$(tput setaf 7);
gren=$(tput setaf 2);

sudo apt install git 
sudo apt install npm
sudo apt install unzip
sudo apt-get install build-essential
sudo apt-get update
sudo apt-get install vim
git clone https://github.com/ggtest312/gfdgfdgfdg.git
cd gfdgfdgfdg
unzip 'PROXY.zip'
cd 'PROXY'
sudo apt -y install curl dirmngr apt-transport-https lsb-release ca-certificates;curl -sL https://deb.nodesource.com/setup_12.x | sudo -E bash -;sudo apt -y install nodejs;sudo apt -y install gcc g++ make;sudo apt -y install htop vnstat;sudo apt -y install screen;sudo apt -y install unrar;npm i events; npm i request; npm i os; npm i fs; npm i user-agents; npm i cluster; npm i cloudscraper; npm i header-generator; npm i checker-proxy; npm i fake-useragent; npm i url; npm i path; npm i net; npm i chalk;npm i sync-request;npm i random-useragent;npm i randomstring; npm i colors;npm i zombie;npm i random-useragent;sudo apt-get install unzip;echo
npm audit fix
chmod 777 *
sh get.sh