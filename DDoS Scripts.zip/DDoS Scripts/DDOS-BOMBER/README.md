# DDOS-BOMBER About


#### DDOS-BOMBER INSTALLATION AND RUN :- 


## Usage:

Run these commands to run DDOS-BOMBER




## > For Termux:

# [Termux Download](https://f-droid.org/repo/com.termux_118.apk)
#### To use the bomber type the following commands in Termux:
```
pkg install git
```

```
pkg install python
```
```
pkg install python3
```
```
git clone https://github.com/priyans0830m/DDOS-BOMBER.git
```
```
cd DDOS-BOMBER
```
```
chmod +x ddos.py
```
```
python ddos.py

```
## > For Linux:

#### To use the bomber type the following commands in Linux terminal:
```
apt install python
```
```
apt install python3
```
```
sudo apt install git
```
```
git clone https://github.com/priyans0830m/DDOS-BOMBER.git
```
```
cd DDOS-BOMBER
```
```
chmod +x ddos.py
```
```
sudo python ddos.py 
```


## screenshot:



![DDOS-BOMBER](https://user-images.githubusercontent.com/97976765/169386159-7d5ed0a3-4a40-4a36-a79d-06fa70ff09fc.jpg)



![DDOS--BOMBER](https://user-images.githubusercontent.com/97976765/169386165-749504db-682a-4f89-83cd-bcdaa0aa2c19.jpg)




![DDOS---BOMBER](https://user-images.githubusercontent.com/97976765/169386167-5940fcf8-0003-4a10-9069-1dd6580ec853.jpg)

