*BACA DULU PERINTAH INI GOBLOG <br>
Ngebot Nih Anjir :v gunain sesuka hatimu.... <br>
Sing Penting Kau Bahagia Selalu dengan defacean mu :* <br>
Disitu ada script ane > ente ganti pake script deface ente > inde.html

**Termux:**
* `pkg install python2`
* `pip2 install requests`
* `pkg install git`
* `git clone https://github.com/Aryaalfahrezi010/bot-deface`
* `cd bot-deface`
* `python2 ngebot.py`

**Linux:**
* `apt-get install python`
* `apt-get install pthon-pip`
* `pip install requests`
* `apt-get install git`
* `git clone https://github.com/Aryaalfahrezi010/bot-deface`
* `cd bot-deface`
* `python ngebot.py`

**NOTE:** sebelum menggunakan alat ini, letakkan skrip deface Anda dengan file ngebot.py, edit file 'target.txt' dan masukkan url target

![image](https://user-images.githubusercontent.com/33353823/118701620-21d4a800-b83e-11eb-8176-e15da2abd2b5.png)


[YOUTUBE](https://www.youtube.com/channel/UCTp6yYYTifItFu5x-BzZzCg) 
