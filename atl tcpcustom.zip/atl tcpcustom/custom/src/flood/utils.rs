use rand::Rng;
use std::collections::HashSet;
use crate::CustomTcpFlags;

pub fn utils_random_port() -> u16 {
    let mut rng = rand::thread_rng();
    rng.gen_range(1024..65535)
}

pub fn utils_random_sequence() -> u32 {
    let mut rng = rand::thread_rng();
    rng.gen_range(0..=u32::MAX)
}

pub fn get_tcp_flags(flag_strs: Vec<String>) -> Vec<CustomTcpFlags> {
    let valid_flags: HashSet<&str> = vec!["fin", "syn", "rst", "psh", "ack", "urg", "cwr", "ece", "ns"]
        .into_iter()
        .collect();

    let mut flags = Vec::new();
    for flag_str in flag_strs {
        if valid_flags.contains(&flag_str.to_lowercase().as_str()) {
            match flag_str.to_lowercase().as_str() {
                "fin" => flags.push(CustomTcpFlags::FIN),
                "syn" => flags.push(CustomTcpFlags::SYN),
                "rst" => flags.push(CustomTcpFlags::RST),
                "psh" => flags.push(CustomTcpFlags::PSH),
                "ack" => flags.push(CustomTcpFlags::ACK),
                "urg" => flags.push(CustomTcpFlags::URG),
                "cwr" => flags.push(CustomTcpFlags::CWR),
                "ece" => flags.push(CustomTcpFlags::ECE),
                "ns" => flags.push(CustomTcpFlags::NS),
                _ => {}
            }
        } else {
            eprintln!("Unknown TCP flag: {}", flag_str);
        }
    }
    flags
}